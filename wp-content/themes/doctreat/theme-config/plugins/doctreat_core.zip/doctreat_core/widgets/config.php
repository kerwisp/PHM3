<?php
if (!defined('ABSPATH')) {
    die('Direct access forbidden.');
}

/**
 *
 * Widgets init
 *
 * @package   Doctreat
 * @author    amentotech
 * @link      https://themeforest.net/user/amentotech/portfolio
 * @version 1.0
 * @since 1.0
 */

require plugin_dir_path( __FILE__ ).'class-recent-posts.php';
require plugin_dir_path( __FILE__ ).'class-adds.php';
require plugin_dir_path( __FILE__ ).'class-apps.php';
require plugin_dir_path( __FILE__ ).'class-contact-info.php';
require plugin_dir_path( __FILE__ ).'class-query-online.php';
require plugin_dir_path( __FILE__ ).'class-news-letters.php';
require plugin_dir_path( __FILE__ ).'class-tweets-widget.php';
require plugin_dir_path( __FILE__ ).'class-apps-downloads.php';
