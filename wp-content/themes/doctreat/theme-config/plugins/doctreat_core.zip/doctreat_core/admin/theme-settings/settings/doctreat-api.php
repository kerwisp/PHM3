<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Mobile Api Settings
 *
 * @throws error
 * @author Amentotech <theamentotech@gmail.com>
 * @return 
 */

/*Redux::setSection( $opt_name, array(
		'title'            => esc_html__( 'Mobile APP Settings', 'doctreat_core' ),
		'id'               => 'doctreat-api-settings',
		'subsection'       => false,
		'desc'       	   => '',
		'icon'       	   => 'el el-key',
		'fields'           => array(
			array(
				'id'       => 'doctreat_api_token',
				'type'     => 'text',
				'title'    => esc_html__( 'Doctreat API token', 'doctreat_core' ),
				'desc'     => esc_html__( 'This API token will be use in React Native Mobile APP, if you are not using Mobile APPS, no need to add anything here', 'doctreat_core' ),
				'default'  => rand(),
			),
		)
	)
);*/